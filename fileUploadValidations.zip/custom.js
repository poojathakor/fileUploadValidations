$("#img_upload").change(function(){
            var ext = $('#img_upload').val().split('.').pop().toLowerCase();
            if($.inArray(ext, ['png']) == -1) {
                $("#img_error").text('please select png file');
                $("#img_upload").val("");
            }
            if($.inArray(ext, ['png']) != -1){
                 $("#img_error").text('');
            }

        });
        $("#doc_upload").change(function(){
            var ext = $('#doc_upload').val().split('.').pop().toLowerCase();
            var file_size=(this.files[0].size/1024/1024).toFixed(2);
            // alert(file_size);
            if($.inArray(ext, ['doc','docx']) == -1 || file_size < 10) {
                $("#doc_error").text('please select doc/ docx file and must be greater than 10MB');
                $("#doc_upload").val("");
            }
            if($.inArray(ext, ['doc','docx']) != -1 && file_size >= 10){
                 $("#doc_error").text('');
            }
        });
       function dynamicFileUpload(){
            var ext = $('#img_doc_upload').val().split('.').pop().toLowerCase();
            if($.inArray(ext, ['doc','docx','gif','png','jpg','jpeg']) == -1) {
                 $("#file_upload_error").text("please select 'doc','docx','gif','png','jpg','jpeg' file");
                $("#img_doc_upload").val("");
            }
        }
        $("#add").click(function(){
            var html = $(".add_content").html();
                $(".control").after(html);
        });
        $(document).ready(function() {
            $("body").on("click",".remove",function(){ 
            $(this).parents(".file_upload").remove();
        });
    });