$("#img_upload").change(function(){
            var ext = $('#img_upload').val().split('.').pop().toLowerCase();
            if($.inArray(ext, ['png']) == -1) {
                $("#img_error").text('please select png file');
                $("#img_upload").val("");
            }
            if($.inArray(ext, ['png']) != -1){
                 $("#img_error").text('');
            }

        });
        $("#doc_upload").change(function(){
            var ext = $('#doc_upload').val().split('.').pop().toLowerCase();
            var file_size=(this.files[0].size/1024/1024).toFixed(2);
            // alert(file_size);
            if($.inArray(ext, ['doc','docx']) == -1 || file_size < 10) {
                $("#doc_error").text('please select doc/ docx file and must be greater than 10MB');
                $("#doc_upload").val("");
            }
            if($.inArray(ext, ['doc','docx']) != -1 && file_size >= 10){
                 $("#doc_error").text('');
            }
        });
       function dynamicFileUpload(n){
            var ext = $('#img_doc_upload' +n).val().split('.').pop().toLowerCase();
            if($.inArray(ext, ['png','doc','jpg','gif','jpeg','docx']) == -1) {
                $("#file_upload_error" +n).text('please select png/ doc/ jpg/ jpeg/ gif/ docx file');
                $("#img_doc_upload" +n).val("");
            }
            if($.inArray(ext, ['png','doc','jpg','gif','jpeg','docx']) != -1){
                $("#file_upload_error" +n).text('');
            }
        }
        var i = 1;
        $("#add").click(function(){
            var html = '<div class="add_content remove_content'+i+'" ><div class="file_upload"><div class="grid"><div class="grid__item one-third"><label>Image/ Doc Upload</label><input type="file" name="img_doc_upload[]" id="img_doc_upload'+i+'" onchange="dynamicFileUpload('+i+');"/><div id="file_upload_error'+i+'"></div></div><div class="grid__item one-third"><label>Delete</label><p><button type="button" id="remove_content'+i+'" class="remove" ><i class="fa fa-trash-o"></i></button></p></div></div></div></div>';
                $(".control").append(html);
                i++;
        });
        $(document).ready(function() {
            $("body").on("click",".remove",function(){ 
                var id = $(this).attr("id");
                // alert(id);
                $("."+id).remove();
            });
        });