/* ###################################################################################################
Extra Function
 ###################################################################################################*/
 function validateEmail(email) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(email)) {
        return true;
    }else{
        return false;
    }
}

/* ###################################################################################################
Pop up Module
 ###################################################################################################*/
  $( document ).ready(function() {
    // function validateUnique(email)
    // {
    //     $.ajax({
                
    //             url: 'email.json',
    //             type: 'GET',
    //             dataType: 'json',
    //             success: function( resp ) {
    //                 for(var i = 0; i < resp.users.length; i++)
    //                 {
    //                     console.log(resp.users[i].email);
    //                     if( email == resp.users[i].email )
    //                     {
    //                         console.log("false");
    //                         $(".email-error").html("its not an unique email address!");
    //                         return false;
    //                         event.preventDefault();
    //                     }
    //                     else
    //                     {
    //                         console.log("true");
    //                     }
    //                 }
                   
    //             },
    //             error: function( req, status, err ) {
    //                 alert( 'something went wrong', status, err );
    //             }
    //         });
    // }

    $('.popup_module').delay(2000).fadeIn(100);
    
    $("#close_popup").click(function(){
        $('.popup_module').css("display","none");
    });
    $("#submit").click(function(event){
        // alert("hi");
        
        if (validateEmail($("#email").val()) == "") {
            $("#email").addClass("error_cls");
            $(".email-error").html("Please enter valid email address");
            // event.preventDefault();
            return false;
        }
        else{
          // event.preventDefault();
                // alert("hi");
                alert("hi");
                $.ajax({
                url: 'email.json',
                type: 'GET',
                dataType: 'json',

                success: function( resp ) {
                    for(var i = 0; i < resp.users.length; i++)
                    {
                        console.log(resp.users[i].email);
                        if($("#email").val() == resp.users[i].email)
                        {
                            console.log("false");
                            $(".email-error").html("its not an unique email address!");
                            return false;
                            // event.preventDefault();
                        }
                        else
                        {
                           console.log("true");
                           
                        }
                    }
                   
                },
                error: function( req, status, err ) {
                    alert( 'something went wrong', status, err );
                }
            });
        }
    });
    
    $("#email").on("keydown",function(){
        if (validateEmail($("#email").val()) != ""){
            $("#email").removeClass("error_cls");
            $(".email-error").empty();
        }
    });
});
 // $( document ).ready(function() {
 //    if($(".ui-datepicker-calendar tbody tr td:first-child span,.ui-datepicker-calendar tbody tr td:last-child span").css("opacity","0.35"))
 //    {
 //        console.log(".ui-datepicker-calendar tbody tr td:first-child span,.ui-datepicker-calendar tbody tr td:last-child span");
       
 //        $(this).attr("title","holiday");
 //        $(this).attr("disabled","disabled");
 //        $(this).addClass("ui-state-disabled");

 //    }  
 // });
// $(".ui-datepicker-calendar tbody tr td:first-child").mouseover(function(e) {
//     if ($(this).hasClass("ui-state-disabled"))
//     {
//         $(".ui-state-disabled").removeClass("ui-state-disabled").attr("title", "this is tooltip");
//         $(this).addClass("ui-state-disabled").attr("title", "tooltip");
//     }
// });
